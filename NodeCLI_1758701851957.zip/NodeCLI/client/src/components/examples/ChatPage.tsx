import { ThemeProvider } from '../ThemeProvider';
import ChatPage from '../../pages/ChatPage';

export default function ChatPageExample() {
  return (
    <ThemeProvider>
      <div className="h-screen">
        <ChatPage />
      </div>
    </ThemeProvider>
  );
}