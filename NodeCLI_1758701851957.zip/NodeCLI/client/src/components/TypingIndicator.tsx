import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export function TypingIndicator() {
  return (
    <div className="flex gap-4 p-4">
      <Avatar className="h-8 w-8 flex-shrink-0">
        <AvatarFallback className="bg-muted text-muted-foreground text-xs font-medium">
          AI
        </AvatarFallback>
      </Avatar>
      
      <div className="flex flex-col items-start">
        <div className="bg-muted rounded-2xl px-4 py-3">
          <div className="flex gap-1">
            <div className="w-2 h-2 bg-muted-foreground rounded-full animate-pulse"></div>
            <div className="w-2 h-2 bg-muted-foreground rounded-full animate-pulse delay-75"></div>
            <div className="w-2 h-2 bg-muted-foreground rounded-full animate-pulse delay-150"></div>
          </div>
        </div>
        <span className="text-xs text-muted-foreground mt-1 px-2">
          Печатает...
        </span>
      </div>
    </div>
  );
}